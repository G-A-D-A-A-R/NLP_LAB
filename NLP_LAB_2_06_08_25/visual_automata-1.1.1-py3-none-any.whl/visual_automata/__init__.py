# __init__.py

# Version of the visual-automata package
__version__ = "1.1.1"
